import { describe, expect, it } from 'vitest';
import { calculateRespectResult, getRespectQuestions, getRespectSituationGuidanceIndex, respectAxisLabels, workplaceRespectRuntimeQuestions, RESPECT_RESULT_TTL_MS } from '@/data/workplaceRespectQuestions';
import { workplaceRespectQuestions as governance } from '@/data/workplaceRespectQuestionGovernance';
import { createRespectResponse, decodeRespectResponse } from '@/diagnostics/workplace-respect/response';
import type { RespectEntry, RespectRiskAxis } from '@/data/workplaceRespectQuestions';
import { getRespectHelpCalls } from '@/diagnostics/workplace-respect/help';

function answersFor(entry: RespectEntry, selected: Record<string, number> = {}) {
  return getRespectQuestions(entry).map((q) => selected[q.id] ?? 0);
}
describe('workplace-respect v0.2', () => {
  it('24문항·안전 우선 순서·안정적인 선택지 ID를 제공한다', () => {
    expect(workplaceRespectRuntimeQuestions).toHaveLength(24);
    expect(getRespectQuestions('action')).toHaveLength(12);
    expect(getRespectQuestions('experience')).toHaveLength(12);
    expect(getRespectQuestions('action')[0].id).toBe('A11');
    expect(getRespectQuestions('experience').slice(0, 2).map(q => q.id)).toEqual(['E11', 'E10']);
    const ids = workplaceRespectRuntimeQuestions.flatMap(q => q.choices.map(c => c.id));
    expect(new Set(ids).size).toBe(ids.length);
    for (const q of workplaceRespectRuntimeQuestions) expect(q.choices.length).toBeGreaterThanOrEqual(4);
    expect(getRespectQuestions('experience').find(q => q.id === 'E07')?.choices).toHaveLength(5);
  });
  it('화면·출처 관리의 문구·축·점수·모든 게이트가 일치하고 출처가 공개 데이터로 새지 않는다', () => {
    for (const q of workplaceRespectRuntimeQuestions) {
      const managed = governance.find(other => other.id === q.id);
      expect(managed).toMatchObject(q);
      expect(managed?.choices).toEqual(q.choices);
      expect(managed?.source.sourceUrl).toMatch(/^https:\/\//);
      expect(managed?.source.reviewStatus).toBe('초안');
      expect(managed?.source.expertReviewer).toBeNull();
      expect('source' in q).toBe(false);
    }
    expect(governance).toHaveLength(24);
  });
  it.each(['action', 'experience'] as const)('%s의 동일 축 중복 응답은 점수를 부풀리지 않고 최대점은 18이다', entry => {
    const riskOnly = Object.fromEntries(getRespectQuestions(entry).filter(q => !['crisisGate', 'resultGate', 'evidenceSupport'].includes(q.axis)).map(q => [q.id, 3]));
    expect(calculateRespectResult(entry, answersFor(entry, riskOnly)).score).toBe(18);
    const prefix = entry === 'action' ? 'A' : 'E';
    const one = calculateRespectResult(entry, answersFor(entry, { [prefix+'02']: 2 }));
    const two = calculateRespectResult(entry, answersFor(entry, { [prefix+'02']: 2, [prefix+'03']: 2 }));
    expect(one.score).toBe(two.score);
  });
  it('애매한 답변 두 개로 업무범위 축을 활성화하지 않는다', () => {
    const r = calculateRespectResult('action', answersFor('action', { A02: 1, A03: 1 }));
    expect(r.score).toBe(1);
    expect(r.axisSummary.activeAxes).not.toContain('workScope');
  });
  it.each(['action', 'experience'] as const)('%s의 핵심 신호 충족과 낮음 결과가 공존하지 않는다', entry => {
    const p = entry === 'action' ? 'A' : 'E';
    const r = calculateRespectResult(entry, answersFor(entry, { [p+'01']: 2, [p+'07']: 2 }));
    expect(r.axisSummary.consultationSignalsMet).toBe(true);
    expect(r.level).toBe('caution');
  });
  it.each(['A06', 'A07', 'A09', 'A12'])('%s 단독 강한 신호도 낮음으로 안내하지 않는다', id => {
    expect(calculateRespectResult('action', answersFor('action', { [id]: 3 })).level).toBe('caution');
  });
  it.each(['E05', 'E07', 'E12'])('%s 단독 강한 신호도 낮음으로 안내하지 않는다', id => {
    expect(calculateRespectResult('experience', answersFor('experience', { [id]: 3 })).level).toBe('caution');
  });
  it('모욕·위협은 업무 관련 여부와 별개로 부적절한 방식 신호가 된다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E01: 2, E05: 2 }));
    expect(r.axisSummary.consultationSignalsMet).toBe(true);
    expect(r.level).toBe('caution');
  });
  it('관계 우위·심한 모욕·실제 불이익은 높은 안내 우선순위로 연결한다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E01: 3, E05: 3, E07: 3 }));
    expect(r.level).toBe('high');
    expect(r.score).toBe(9);
  });
  it('관계 우위 응답 없이 높은 총점만으로 핵심 기준이나 high를 만들지 않는다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E03: 3, E05: 3, E06: 3, E08: 3, E12: 3 }));
    expect(r.level).toBe('caution');
    expect(r.axisSummary.consultationSignalsMet).toBe(false);
  });
  it.each([
    ['action', 'A02'], ['action', 'A03'], ['action', 'A04'],
    ['experience', 'E02'], ['experience', 'E03'], ['experience', 'E04'],
  ] as const)('%s 관계 우위와 함께 나타난 %s 신호는 낮음이 아니라 주의로 안내한다', (entry, id) => {
    const relationId = entry === 'action' ? 'A01' : 'E01';
    const axis = getRespectQuestions(entry).find(q => q.id === id)!.axis as RespectRiskAxis;
    const alone = calculateRespectResult(entry, answersFor(entry, { [id]: 2 }));
    const withRelation = calculateRespectResult(entry, answersFor(entry, { [relationId]: 2, [id]: 2 }));
    expect(alone.level).toBe('low');
    expect(withRelation.level).toBe('caution');
    expect(withRelation.score).toBe(4);
    expect(withRelation.axisSummary.consultationSignalsMet).toBe(false);
    expect(withRelation.axisSummary.activeAxes).toEqual(['relationPower', axis]);
    expect(withRelation.summary).toContain(respectAxisLabels[axis]);
    expect(withRelation.title).not.toBe(alone.title);
  });
  it.each([
    ['action', 'A01'], ['action', 'A08'], ['experience', 'E01'], ['experience', 'E08'],
  ] as const)('%s의 %s 최고점만으로는 주의로 올리지 않는다', (entry, id) => {
    const r = calculateRespectResult(entry, answersFor(entry, { [id]: 3 }));
    expect(r.score).toBe(3);
    expect(r.level).toBe('low');
    expect(r.axisSummary.activeAxes).toHaveLength(1);
    expect(r.axisSummary.consultationSignalsMet).toBe(false);
  });
  it.each(['action', 'experience'] as const)('%s에서 관계 우위와 다른 위험 문항 하나의 조합은 그 문항이 2점 이상일 때만 주의다', entry => {
    const items = getRespectQuestions(entry);
    const relation = items.find(q => q.axis === 'relationPower')!;
    const others = items.filter(q => q.axis !== 'relationPower' && q.axis !== 'repetition' && !['crisisGate', 'resultGate', 'evidenceSupport'].includes(q.axis));
    let checked = 0;
    for (const relationChoice of [2, 3]) {
      for (const q of others) {
        q.choices.forEach((choice, index) => {
          const r = calculateRespectResult(entry, answersFor(entry, { [relation.id]: relationChoice, [q.id]: index }));
          expect(r.level, `${relation.id}=${relationChoice}, ${q.id}=${index}`).toBe(choice.score >= 2 || choice.gate ? 'caution' : 'low');
          checked++;
        });
      }
    }
    expect(checked).toBe(others.reduce((count, q) => count + q.choices.length, 0) * 2);
  });
  it.each([1, 2])('E10 도움 응답 %s는 위험 점수·축을 바꾸지 않는다', choice => {
    const base = { E01: 2, E03: 2, E05: 2 };
    const r = calculateRespectResult('experience', answersFor('experience', { ...base, E10: choice }));
    const before = calculateRespectResult('experience', answersFor('experience', base));
    expect(r.score).toBe(before.score);
    expect(r.axisSummary).toEqual(before.axisSummary);
    expect(r.level).toBe(before.level);
    expect(r.support).toBe(true);
  });
  it('마음건강 도움만 선택하면 선택하지 않은 관계·업무 신호를 요약하지 않는다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E10: 2 }));
    expect(r.score).toBe(0);
    expect(r.level).toBe('caution');
    expect(r.summary).toContain('마음건강');
    expect(r.summary).not.toContain('관계');
    expect(r.summary).not.toContain('모욕');
  });
  it('A10 중단 게이트는 총점 0으로 최소 주의를 보장한다', () => {
    const r = calculateRespectResult('action', answersFor('action', { A10: 2 }));
    expect(r.score).toBe(0);
    expect(r.level).toBe('caution');
    expect(r.primaryActions.join(' ')).not.toContain('사적인 부탁');
  });
  it.each(['action', 'experience'] as const)('%s의 단발·모름은 반복성 점수를 바꾸지 않는다', entry => {
    const id = entry === 'action' ? 'A08' : 'E08';
    const zero = calculateRespectResult(entry, answersFor(entry));
    const unknown = calculateRespectResult(entry, answersFor(entry, { [id]: 1 }));
    expect(unknown.score).toBe(zero.score);
    expect(unknown.level).toBe(zero.level);
    expect(unknown.uncertainCount).toBe(1);
    expect(unknown.summary).toContain('판단하기 어렵다');
  });
  it.each(['action', 'experience'] as const)('%s의 첫 안전 응답만으로 바로 긴급 결과를 제공한다', entry => {
    const r = calculateRespectResult(entry, [2]);
    expect(r.level).toBe('urgent');
    expect(r.score).toBe(0);
    expect(r.crisisKinds).toEqual(['physicalSafety']);
    const text = [...r.primaryActions, ...r.supportActions].join(' ');
    expect(text).toContain('112');
    expect(text).toContain('119');
    expect(text).not.toContain('109');
  });
  it('자해의 현재 실행 위험과 반복 생각을 분리한다', () => {
    const urgent = calculateRespectResult('experience', answersFor('experience', { E10: 3 }));
    const recurring = calculateRespectResult('experience', answersFor('experience', { E10: 2 }));
    expect(urgent.crisisKinds).toEqual(['selfHarm']);
    expect(urgent.level).toBe('urgent');
    expect(recurring.level).toBe('caution');
    expect(recurring.support).toBe(true);
  });
  it('도움 응답의 빈도만으로 임상 안전이나 도움 시한을 확정하지 않는다', () => {
    const none = calculateRespectResult('experience', answersFor('experience'));
    const passing = calculateRespectResult('experience', answersFor('experience', { E10: 1 }));
    const recurring = calculateRespectResult('experience', answersFor('experience', { E10: 2 }));
    expect(none.supportKind).toBeNull();
    expect(none.supportNotice).toBeNull();
    expect([passing.level, passing.score, recurring.level, recurring.score]).toEqual(['caution', 0, 'caution', 0]);
    expect(passing.supportKind).toBe('passing');
    expect(recurring.supportKind).toBe('recurring');
    expect(passing.supportNotice?.title).toBe('도움받을 수 있는 곳');
    expect(recurring.supportNotice?.title).toBe('도움받을 수 있는 곳');
    expect(recurring.title).toBe('사람과 연결해 현재 상태를 확인하세요');
    expect(recurring.title).not.toBe(passing.title);
    expect(recurring.supportActions.join(' ')).not.toContain('오늘 안에');
    expect(recurring.supportNotice?.body).toContain('안전을 판단할 수 없습니다');
    expect(recurring.supportActions.join(' ')).toContain('109');
    expect(passing.supportActions.join(' ')).not.toContain('오늘 안에');
  });
  it('반복되는 자해 생각은 높음 결과에서도 제목을 도움 연결로 바꾸고 등급은 유지한다', () => {
    const base = { E01: 3, E05: 3, E07: 3 };
    const before = calculateRespectResult('experience', answersFor('experience', base));
    const after = calculateRespectResult('experience', answersFor('experience', { ...base, E10: 2 }));
    expect(before.level).toBe('high');
    expect(before.supportNotice).toBeNull();
    expect(after.level).toBe('high');
    expect(after.score).toBe(before.score);
    expect(after.title).toBe('사람과 연결해 현재 상태를 확인하세요');
    expect(after.supportNotice?.title).toBe('도움받을 수 있는 곳');
  });
  it.each([['action', 'A01', 1], ['experience', 'E01', 2]] as const)('%s의 상황 안내는 안전 문항이 끝난 첫 위험 문항(%s)에서 보인다', (entry, firstRiskId, index) => {
    const items = getRespectQuestions(entry);
    expect(getRespectSituationGuidanceIndex(entry)).toBe(index);
    expect(items[index].id).toBe(firstRiskId);
    expect(items.slice(0, index).every(q => q.category === '안전')).toBe(true);
    expect(items[index].category).not.toBe('안전');
  });
  it('발생 문항의 3점은 정도가 심한 경우로 정의되고 관계 문항만 동의 척도를 쓴다', () => {
    const occurrenceIds = ['A04', 'A05', 'A06', 'A12', 'E04', 'E12'];
    const agreementIds = workplaceRespectRuntimeQuestions.filter(q => q.choices.some(c => c.text === '매우 그렇다')).map(q => q.id);
    expect(agreementIds).toEqual(['A01', 'E01']);
    for (const id of occurrenceIds) {
      const q = workplaceRespectRuntimeQuestions.find(item => item.id === id)!;
      expect(q.choices.map(c => c.score)).toEqual([0, 0, 2, 3]);
      expect(q.choices.map(c => c.id)).toEqual([`${id}:no`, `${id}:uncertain`, `${id}:present`, `${id}:severe`]);
      expect(q.choices[2].text).not.toBe('그렇다');
      expect(q.choices[3].text).not.toBe('매우 그렇다');
    }
  });
  it('현재 안전 문항의 과거형 선택지는 질문에도 이미 일어난 일을 포함한다', () => {
    const crisisQuestions = workplaceRespectRuntimeQuestions.filter(q => q.axis === 'crisisGate');
    expect(crisisQuestions.map(q => q.id)).toEqual(['A11', 'E10', 'E11']);
    for (const q of crisisQuestions) {
      expect(q.choices.some(c => c.text.includes('이미'))).toBe(true);
      expect(q.prompt).toContain('이미');
      expect(q.prompt).toContain('지금');
    }
  });
  it.each([['action', 'A11'], ['experience', 'E11']] as const)('%s의 %s "안전한지 확신하기 어렵다"는 112·119 안전 안내를 앞세운다', (entry, id) => {
    const before = calculateRespectResult(entry, answersFor(entry));
    const after = calculateRespectResult(entry, answersFor(entry, { [id]: 1 }));
    expect(before.level).toBe('low');
    expect(before.safetyNotice).toBeNull();
    expect([after.level, after.score, after.crisis, after.safetyUncertain]).toEqual(['caution', 0, false, true]);
    expect(after.safetyNotice?.title).toBe('안전부터 확인하세요');
    expect(after.safetyNotice?.body).toContain('112');
    expect(after.safetyNotice?.body).toContain('119');
    expect(after.supportNotice).toBeNull();
  });
  it.each([['action', 'A11'], ['experience', 'E11']] as const)('%s의 %s 안전 확인 응답은 위험 문항의 "판단하기 어렵다"로 요약하지 않는다', (entry, id) => {
    const safetyOnly = calculateRespectResult(entry, answersFor(entry, { [id]: 1 }));
    const riskUncertain = calculateRespectResult(entry, answersFor(entry, { [id]: 1, [entry === 'action' ? 'A08' : 'E08']: 1 }));
    expect(safetyOnly.uncertainCount).toBe(0);
    expect(safetyOnly.summary).not.toContain('판단하기 어렵다');
    expect(riskUncertain.uncertainCount).toBe(1);
    expect(riskUncertain.summary).toContain('판단하기 어렵다');
  });
  it('안전 확인 안내는 높음 결과에서도 유지되고 긴급 결과에는 따로 붙지 않는다', () => {
    const high = calculateRespectResult('experience', answersFor('experience', { E11: 1, E01: 3, E05: 3, E07: 3 }));
    expect(high.level).toBe('high');
    expect(high.safetyNotice?.title).toBe('안전부터 확인하세요');
    const urgent = calculateRespectResult('experience', [2]);
    expect(urgent.level).toBe('urgent');
    expect(urgent.safetyNotice).toBeNull();
    expect(urgent.supportNotice).toBeNull();
    expect(urgent.summary.startsWith('지금')).toBe(false);
    expect(urgent.summary).toContain('지금도 위험하거나 다친 사람이 있다면');
  });
  it('높음 경계는 핵심 기준 + 8점이며 7점은 주의다', () => {
    const seven = calculateRespectResult('experience', answersFor('experience', { E01: 2, E02: 2, E08: 3 }));
    const eight = calculateRespectResult('experience', answersFor('experience', { E01: 2, E02: 2, E08: 3, E06: 1 }));
    expect([seven.axisSummary.consultationSignalsMet, seven.score, seven.level]).toEqual([true, 7, 'caution']);
    expect([eight.axisSummary.consultationSignalsMet, eight.score, eight.level]).toEqual([true, 8, 'high']);
  });
  it('다른 주의 조건 없이 총점 6점이면 주의, 5점이면 낮음이다', () => {
    const five = calculateRespectResult('action', answersFor('action', { A04: 2, A08: 3 }));
    const six = calculateRespectResult('action', answersFor('action', { A04: 2, A08: 3, A03: 1 }));
    expect([five.score, five.level, five.axisSummary.activeAxes.length]).toEqual([5, 'low', 2]);
    expect([six.score, six.level, six.axisSummary.activeAxes.length]).toEqual([6, 'caution', 2]);
  });
  it.each([2, 3])('A10 확인 응답 %s는 점수 없이 최소 주의를 보장한다', choice => {
    const r = calculateRespectResult('action', answersFor('action', { A10: choice }));
    expect([r.level, r.score, r.safetyUncertain]).toEqual(['caution', 0, false]);
    expect(r.safetyNotice).toBeNull();
  });
  it('잠깐 스치는 자해 생각도 일터 결과보다 도움 연결을 앞세운다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E01: 3, E05: 3, E07: 3, E10: 1 }));
    expect(r.level).toBe('high');
    expect(r.title).toBe('지금 상태와 도움 경로를 확인하세요');
    expect(r.supportNotice?.title).toBe('도움받을 수 있는 곳');
    expect(r.primaryActions[0]).not.toContain('109');
  });
  it('반복되는 자해 생각의 109 연결은 상단 도움 안내가 맡고 지금 할 일에서는 반복하지 않는다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E01: 2, E05: 2, E10: 2 }));
    expect(r.level).toBe('caution');
    expect(r.supportNotice?.body).toContain('109');
    expect(r.primaryActions).toHaveLength(3);
    expect(r.primaryActions.join(' ')).not.toContain('109');
  });
  it.each([1, 2])('도움 안내 %s는 화면에 없는 점수를 가리키거나 화면 제목을 되풀이하지 않는다', choice => {
    const r = calculateRespectResult('experience', answersFor('experience', { E10: choice }));
    expect(r.supportNotice?.body).toContain('혼자 감당하지 않아도 됩니다');
    expect(r.supportNotice?.body).toContain('109');
    expect(r.supportNotice?.body).not.toContain('점수');
    expect(r.supportNotice?.title).not.toBe(r.title);
    expect(r.summary).not.toContain('점수');
  });
  it('내 행동 조언은 실제로 고른 행동부터 안내한다', () => {
    const none = calculateRespectResult('action', answersFor('action'));
    const reported = calculateRespectResult('action', answersFor('action', { A01: 3, A06: 3, A07: 2 }));
    expect(none.primaryActions[0]).toBe('업무 목적과 기준을 짧게 설명하세요.');
    expect(none.primaryActions.join(' ')).not.toContain('모욕');
    expect(reported.level).toBe('high');
    expect(reported.primaryActions[0]).toContain('모욕·비하·위협');
    expect(reported.primaryActions[1]).toContain('불이익을 암시한');
    expect(reported.primaryActions).toHaveLength(3);
    expect(reported.primaryActions.join(' ')).not.toContain('사적인 부탁');
  });
  it('결과 요약의 축 이름은 고르지 않은 일상 영향을 단정하지 않는다', () => {
    const r = calculateRespectResult('experience', answersFor('experience', { E05: 2 }));
    expect(r.summary).toContain('존중을 해치는 말·행동 또는 일상 영향');
    expect(r.summary).not.toContain('존중·일상에 미친 영향');
  });
  it('A10은 긴급 안전 문항이 아닌 마지막 확인 문항이고 안전 분류는 위기 문항만 쓴다', () => {
    const action = getRespectQuestions('action');
    expect(action.at(-1)?.id).toBe('A10');
    expect(action.at(-1)?.category).toBe('확인');
    expect(workplaceRespectRuntimeQuestions.filter(q => q.category === '안전').map(q => q.id)).toEqual(['A11', 'E10', 'E11']);
  });
  it.each(['action', 'experience'] as const)('%s에서 위험 응답을 한 단계 올려도 등급이 내려가지 않는다(표본)', entry => {
    const items = getRespectQuestions(entry);
    const risk = items.map((q, i) => [q, i] as const).filter(([q]) => !['crisisGate', 'resultGate', 'evidenceSupport'].includes(q.axis));
    const rank = { low: 0, caution: 1, high: 2, urgent: 3 };
    let seed = 7;
    const next = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed; };
    let checked = 0;
    for (let n = 0; n < 2000; n++) {
      const answers = items.map(() => 0);
      risk.forEach(([, i]) => { answers[i] = next() % 4; });
      const [q, i] = risk[next() % risk.length];
      const higher = q.choices.findIndex(c => c.score > q.choices[answers[i]].score);
      if (higher < 0) continue;
      const raised = [...answers];
      raised[i] = higher;
      expect(rank[calculateRespectResult(entry, raised).level]).toBeGreaterThanOrEqual(rank[calculateRespectResult(entry, answers).level]);
      checked++;
    }
    expect(checked).toBeGreaterThan(1000);
  });
  it('잘못된 선택지 인덱스·비정수는 응답 수에서 제외한다', () => {
    const r = calculateRespectResult('action', [-1, 99, 1.5, NaN]);
    expect(r.answeredCount).toBe(0);
    expect(r.score).toBe(0);
  });
});
describe('versioned respect response', () => {
  const now = 1_800_000_000_000;
  it('문항·선택지 ID와 두 버전으로 저장하고 기록 배열 순서에 의존하지 않는다', () => {
    const answers = answersFor('experience', { E05: 3 });
    const response = createRespectResponse('experience', answers, now);
    expect(response.instrumentVersion).toBe('workplace-respect-v0.2.2');
    expect(response.scoringVersion).toBe('workplace-respect-risk-v0.2.2');
    expect('answers' in response).toBe(false);
    expect(decodeRespectResponse({ ...response, responses: [...response.responses].reverse() }, 'experience', now)?.answers).toEqual(answers);
  });
  it('긴급 신호가 있는 일부 응답만 복원·공유할 수 있다', () => {
    const response = createRespectResponse('action', [2], now);
    const restored = decodeRespectResponse(response, 'action', now);
    expect(restored).not.toBeNull();
    expect(calculateRespectResult('action', restored!.answers).answeredCount).toBe(1);
    expect(() => createRespectResponse('action', [0], now)).toThrow('Incomplete');
    expect(decodeRespectResponse({ ...response, responses: [] }, 'action', now)).toBeNull();
  });
  it('이전 버전·다른 관점·만료·미래 시각을 거절한다', () => {
    const response = createRespectResponse('action', answersFor('action'), now);
    expect(decodeRespectResponse({ ...response, instrumentVersion: 'workplace-respect-v0.1' }, 'action', now)).toBeNull();
    expect(decodeRespectResponse({ ...response, scoringVersion: 'old' }, 'action', now)).toBeNull();
    expect(decodeRespectResponse(response, 'experience', now)).toBeNull();
    expect(decodeRespectResponse(response, 'action', now + RESPECT_RESULT_TTL_MS)).toBeNull();
    expect(decodeRespectResponse({ ...response, createdAt: now + 1 }, 'action', now)).toBeNull();
  });
  it('직전 버전과 옛 선택지 ID를 거절한다', () => {
    const response = createRespectResponse('action', answersFor('action'), now);
    expect(decodeRespectResponse({ ...response, instrumentVersion: 'workplace-respect-v0.2' }, 'action', now)).toBeNull();
    expect(decodeRespectResponse({ ...response, scoringVersion: 'workplace-respect-risk-v0.2' }, 'action', now)).toBeNull();
    const oldChoice = response.responses.map(item => (item.questionId === 'A04' ? { ...item, choiceId: 'A04:yes' } : item));
    expect(decodeRespectResponse({ ...response, responses: oldChoice }, 'action', now)).toBeNull();
    expect(decodeRespectResponse(response, 'action', now)).not.toBeNull();
  });
  it('위기 응답은 첫 위기 선택에서 끝나는 앞부분만 허용한다', () => {
    const valid = createRespectResponse('experience', [0, 3], now);
    expect(valid.responses.map(item => item.choiceId)).toEqual(['E11:safe', 'E10:immediate']);
    expect(decodeRespectResponse(valid, 'experience', now)).not.toBeNull();
    const skippedFirst = { ...valid, responses: [{ questionId: 'E10', choiceId: 'E10:immediate' }] };
    expect(decodeRespectResponse(skippedFirst, 'experience', now)).toBeNull();
    const notPrefix = { ...valid, responses: [{ questionId: 'E05', choiceId: 'E05:severe' }, { questionId: 'E11', choiceId: 'E11:imminent' }] };
    expect(decodeRespectResponse(notPrefix, 'experience', now)).toBeNull();
    const afterCrisis = { ...valid, responses: [{ questionId: 'E11', choiceId: 'E11:imminent' }, { questionId: 'E10', choiceId: 'E10:recurring' }] };
    expect(decodeRespectResponse(afterCrisis, 'experience', now)).toBeNull();
    expect(() => createRespectResponse('experience', [2, 2], now)).toThrow('after a crisis answer');
  });
  it('문항 중복·없는 문항·다른 문항의 선택지·부분 비긴급 응답을 거절한다', () => {
    const response = createRespectResponse('action', answersFor('action'), now);
    const first = response.responses[0];
    expect(decodeRespectResponse({ ...response, responses: [...response.responses, first] }, 'action', now)).toBeNull();
    expect(decodeRespectResponse({ ...response, responses: [{ questionId: 'A99', choiceId: 'A99:no' }] }, 'action', now)).toBeNull();
    expect(decodeRespectResponse({ ...response, responses: [{ ...first, choiceId: 'E11:imminent' }] }, 'action', now)).toBeNull();
    expect(decodeRespectResponse({ ...response, responses: [first] }, 'action', now)).toBeNull();
  });
});

describe('v0.2.2 review regressions', () => {
  it('A10의 지금 중단 선택은 단순 기준 확인과 달리 중단 행동을 먼저 안내한다', () => {
    const review = calculateRespectResult('action', answersFor('action', { A10: 2 }));
    const stop = calculateRespectResult('action', answersFor('action', { A10: 3 }));
    expect(stop.primaryActions[0]).toContain('지금 멈추고');
    expect(review.primaryActions[0]).not.toContain('지금 멈추고');
    expect([review.level, stop.level, review.score, stop.score]).toEqual(['caution', 'caution', 0, 0]);
  });
  it.each(['action', 'experience'] as const)('%s에서 관계와 반복의 최고점 6점만으로 주의를 만들지 않는다', entry => {
    const p = entry === 'action' ? 'A' : 'E';
    const r = calculateRespectResult(entry, answersFor(entry, { [p + '01']: 3, [p + '08']: 3 }));
    expect([r.score, r.level, r.axisSummary.consultationSignalsMet]).toEqual([6, 'low', false]);
  });
  it('불이익 걱정은 실제 암시와 달리 불이익 축·높음을 만들지 않고 상담은 안내한다', () => {
    const worry = calculateRespectResult('experience', answersFor('experience', { E01: 3, E07: 4, E08: 3 }));
    const implied = calculateRespectResult('experience', answersFor('experience', { E01: 3, E07: 2, E08: 3 }));
    expect(worry.axisSummary.scores.disadvantage).toBe(0);
    expect(worry.level).toBe('caution');
    expect(worry.retaliationConcern).toBe(true);
    expect(worry.summary).toContain('실제 불이익 행위가 확인되었다는 뜻은 아닙니다');
    expect(implied.axisSummary.scores.disadvantage).toBe(2);
    expect(implied.retaliationConcern).toBe(false);
  });
  it('업무상 필요성의 모름·해당 없음을 사실 응답과 구분하고 강한 신호를 낮추지 않는다', () => {
    const unknown = calculateRespectResult('experience', answersFor('experience', { E02: 5 }));
    const absent = calculateRespectResult('experience', answersFor('experience', { E02: 4 }));
    expect(unknown.informationLimited).toBe(true);
    expect(unknown.summary).toContain('낮은 위험으로 해석할 수 없습니다');
    expect(absent.informationLimited).toBe(false);
    const high = calculateRespectResult('experience', answersFor('experience', { E01: 3, E05: 3, E07: 3, E02: 5 }));
    expect([high.level, high.informationLimited]).toEqual(['high', false]);
  });
  it('복합 도움에서 신체 안전을 먼저, 자해 실행 응답에서는 응급 도움을 먼저 표시한다', () => {
    const combined = calculateRespectResult('experience', answersFor('experience', { E11: 1, E10: 2 }));
    expect(getRespectHelpCalls(combined).map(call => call.number)).toEqual(['112', '119', '109']);
    const immediate = calculateRespectResult('experience', [0, 3]);
    expect(getRespectHelpCalls(immediate).map(call => call.number)).toEqual(['119', '112', '109']);
  });
  it('이전 v0.2.1의 불이익 걱정 응답을 암시로 재해석하지 않는다', () => {
    const response = createRespectResponse('experience', answersFor('experience', { E07: 2 }));
    expect(decodeRespectResponse({ ...response, instrumentVersion: 'workplace-respect-v0.2.1', scoringVersion: 'workplace-respect-risk-v0.2.1' }, 'experience')).toBeNull();
    const wrongChoice = response.responses.map(item => item.questionId === 'E07' ? { ...item, choiceId: 'E07:expected' } : item);
    expect(decodeRespectResponse({ ...response, responses: wrongChoice }, 'experience')).toBeNull();
  });
});
