'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { LeafLineArt } from '@/components/LeafLineArt';
import ProgressBar from '@/components/ProgressBar';
import {
  buildRespectResultUrl,
  getRespectQuestions,
  getRespectResultStorageKey,
  getRespectSituationGuidanceIndex,
  RESPECT_SITUATION_GUIDANCE,
  RESPECT_START_NOTICE,
  calculateRespectResult,
  type RespectEntry,
  respectEntryLabels,
} from '@/data/workplaceRespectQuestions';
import { createRespectResponse } from '@/diagnostics/workplace-respect/response';
import EmergencyHelpStrip from '../EmergencyHelpStrip';
import { getRespectHelpCalls } from '@/diagnostics/workplace-respect/help';

const categoryEmoji: Record<string, string> = {
  관계: '🤝',
  업무범위: '📋',
  존중: '💬',
  사적요구: '🧾',
  불이익: '⚖️',
  반복: '🔁',
  기록: '🗂️',
  확인: '🔎',
  안전: '🛟',
};

const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary-accent)] focus-visible:ring-offset-2';

export default function RespectCheckClient({ entry }: { entry: RespectEntry }) {
  const router = useRouter();
  const questions = getRespectQuestions(entry);
  const [answers, setAnswers] = useState<number[]>([]);
  const [storageBlocked, setStorageBlocked] = useState(false);
  const [pendingHelpAnswers, setPendingHelpAnswers] = useState<number[] | null>(null);
  const helpHeadingRef = useRef<HTMLHeadingElement>(null);
  const currentQuestion = questions[answers.length];
  const helpResult = pendingHelpAnswers ? calculateRespectResult(entry, pendingHelpAnswers) : null;
  const label = respectEntryLabels[entry];

  useEffect(() => {
    try { sessionStorage.removeItem(getRespectResultStorageKey(entry)); } catch { /* 저장소 사용 불가 */ }
  }, [entry]);
  useEffect(() => { if (pendingHelpAnswers) helpHeadingRef.current?.focus(); }, [pendingHelpAnswers]);

  const handleSelect = useCallback((choiceIndex: number) => {
    const nextAnswers = [...answers, choiceIndex];
    const choice = currentQuestion.choices[choiceIndex];
    if (choice?.support || (currentQuestion.axis === 'crisisGate' && choice?.gate) || choice?.crisis) {
      setPendingHelpAnswers(nextAnswers);
      if (!choice.crisis) return;
    }
    if (currentQuestion.choices[choiceIndex]?.crisis || nextAnswers.length >= questions.length) {
      try {
        sessionStorage.setItem(
          getRespectResultStorageKey(entry),
          JSON.stringify(createRespectResponse(entry, nextAnswers)),
        );
      } catch {
        // 결과는 이 탭의 저장소로만 넘기므로, 저장이 막히면 결과 화면 대신 안내를 보여준다.
        setStorageBlocked(true);
        return;
      }
      router.push(buildRespectResultUrl(entry));
      return;
    }
    setAnswers(nextAnswers);
  }, [answers, currentQuestion, entry, questions.length, router]);

  const handleBack = () => {
    if (pendingHelpAnswers) { setPendingHelpAnswers(null); setStorageBlocked(false); }
    else setAnswers((prev) => prev.slice(0, -1));
  };
  const handleQuit = () => router.push('/respect');

  if (!currentQuestion) return null;

  return (
    <div className="animate-fade-in relative -mx-6 -mb-6 -mt-4 flex flex-1 flex-col overflow-y-auto bg-white px-6 pb-6 pt-4 sm:-mx-6 sm:-mb-8 sm:-mt-6 sm:px-6 sm:pb-8 sm:pt-6">
      <LeafLineArt className="pointer-events-none absolute -right-16 top-16 h-52 w-52 text-[#b9c8aa] opacity-[0.16]" />
      <LeafLineArt className="pointer-events-none absolute -left-24 bottom-10 h-56 w-56 rotate-[-18deg] text-[#cbd6c0] opacity-[0.14]" />

      <div className="relative z-10">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-primary-accent)]">
              일터 존중 점검
            </p>
            <h1 className="text-[17px] font-bold text-[var(--color-text)]">{label.title}</h1>
          </div>
          <div className="flex gap-1.5">
            {(answers.length > 0 || pendingHelpAnswers) && (
              <button
                type="button"
                onClick={handleBack}
                className={`rounded-full border border-[var(--color-border)] px-3 py-1.5 text-[13px] font-medium text-[var(--color-text-secondary)] hover:bg-[var(--color-card)] hover:text-[var(--color-text)] ${focusRing}`}
              >
                ← 이전
              </button>
            )}
            <button
              type="button"
              onClick={handleQuit}
              className={`rounded-full border border-[var(--color-border)] px-3 py-1.5 text-[13px] font-medium text-[var(--color-text-secondary)] hover:bg-[var(--color-card)] hover:text-[var(--color-text)] ${focusRing}`}
            >
              중단
            </button>
          </div>
        </div>

        <ProgressBar current={answers.length + 1} total={questions.length} ariaLabel="자가점검 진행률" />

        {helpResult ? (
          <section aria-labelledby="respect-check-help-title" className="rounded-[var(--radius-md)] border border-[var(--color-primary-muted)] bg-[var(--color-card)] p-4">
            <h2 ref={helpHeadingRef} tabIndex={-1} id="respect-check-help-title" className="text-[18px] font-bold text-[var(--color-text)]">지금은 사람의 도움을 먼저 확인하세요</h2>
            <p className="mt-2 text-[14px] leading-relaxed text-[var(--color-text-secondary)]">점검을 끝내지 않아도 도움을 받을 수 있습니다. 이 응답만으로 현재 안전을 판단하지 않습니다.</p>
            {[helpResult.safetyNotice, helpResult.supportNotice].filter(notice => notice !== null).map(notice => <p key={notice.title} className="mt-3 text-[14px] leading-relaxed text-[var(--color-text)]">{notice.body}</p>)}
            {helpResult.crisis && <p className="mt-3 text-[14px] leading-relaxed text-[var(--color-text)]">{helpResult.primaryActions.join(' ')}</p>}
            <div className="mt-4 flex flex-col gap-2">
              {getRespectHelpCalls(helpResult).map((call, index) => <a key={call.href} href={call.href} className={`flex min-h-[48px] items-center justify-center rounded-[var(--radius-md)] border border-[var(--color-primary-muted)] px-3 text-[14px] font-semibold ${index === 0 ? 'bg-[var(--color-primary)] text-white' : 'bg-[var(--color-bg)] text-[var(--color-primary)]'} ${focusRing}`}>{call.number} {call.label}</a>)}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {!helpResult.crisis && <button type="button" onClick={() => { setAnswers(pendingHelpAnswers!); setPendingHelpAnswers(null); }} className={`min-h-[48px] rounded-full border border-[var(--color-border)] px-4 text-[14px] ${focusRing}`}>점검 계속</button>}
              <button type="button" onClick={handleQuit} className={`min-h-[48px] rounded-full border border-[var(--color-border)] px-4 text-[14px] ${focusRing}`}>여기서 마치기</button>
            </div>
            {storageBlocked && <p role="alert" className="mt-3 text-[13px] text-red-700">브라우저 저장소를 사용할 수 없어 결과 화면으로 이동하지 못했습니다. 위 도움 경로는 저장 없이 이용할 수 있습니다.</p>}
          </section>
        ) : <div className="animate-fade-in">
          <div className="mb-3.5 inline-flex items-center gap-1 text-[12px] font-bold uppercase tracking-wide text-[var(--color-primary-accent)]">
            <span aria-hidden="true">{categoryEmoji[currentQuestion.category]}</span>
            <span>{currentQuestion.category}</span>
          </div>

          <div className="mb-3 text-5xl font-extrabold leading-none tracking-tighter text-[var(--color-primary-muted)]">
            {String(answers.length + 1).padStart(2, '0')}
          </div>

          <h2 className="mb-8 text-[18px] font-semibold leading-[1.65] tracking-tight text-[var(--color-text)]">
            {currentQuestion.prompt}
          </h2>

          <div className="space-y-2">
            {currentQuestion.choices.map((choice, index) => (
              <button
                key={choice.text}
                type="button"
                onClick={() => handleSelect(index)}
                className={`choice-button relative w-full rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-bg)] py-[18px] pr-5 pl-[48px] text-left text-[15px] leading-relaxed text-[var(--color-text)] shadow-sm ${focusRing}`}
              >
                <span className="absolute left-[18px] top-1/2 flex h-[22px] w-[22px] -translate-y-1/2 items-center justify-center rounded-md border border-[var(--color-border)] bg-[var(--color-card)] text-[12px] font-bold text-[var(--color-text-muted)]">
                  {String.fromCharCode(65 + index)}
                </span>
                {choice.text}
              </button>
            ))}
          </div>

          {storageBlocked && (
            <p role="alert" className="mt-4 text-[13px] leading-relaxed text-red-700">
              브라우저 저장소를 사용할 수 없어 결과를 표시하지 못했어요. 사생활 보호 모드나 저장소 차단 설정을 확인한 뒤 다시 시도해 주세요.
            </p>
          )}

          {answers.length === 0 && (
            <p className="mt-6 text-[12px] leading-relaxed text-[var(--color-text-muted)]">{RESPECT_START_NOTICE}</p>
          )}
          {answers.length === getRespectSituationGuidanceIndex(entry) && (
            <div className="mt-6 rounded-[var(--radius-md)] bg-[var(--color-card)] px-4 py-3">
              <p className="mb-1 text-[12px] font-bold text-[var(--color-text-secondary)]">응답 기준</p>
              <p className="text-[12px] leading-relaxed text-[var(--color-text-muted)]">{RESPECT_SITUATION_GUIDANCE}</p>
            </div>
          )}
          {currentQuestion.axis === 'crisisGate' && <div className="mt-6"><EmergencyHelpStrip compact entry={entry} /></div>}
        </div>}
      </div>
    </div>
  );
}
