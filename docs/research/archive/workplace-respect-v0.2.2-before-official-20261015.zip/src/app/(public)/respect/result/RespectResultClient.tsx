'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import AiAdviceSheet from '@/components/AiAdviceSheet';
import { LeafLineArt } from '@/components/LeafLineArt';
import { getClientIdHeader } from '@/lib/client-id';
import { RESPECT_MAX_HISTORY_MESSAGES } from '@/lib/constants';
import { trimHistoryToLimit } from '@/lib/sanitize';
import { AI_CHAT_ENABLED } from '@/data/appVariant';
import {
  calculateRespectResult,
  getRespectResultStorageKey,
  RESPECT_RESULT_TTL_MS,
  RESPECT_RESULT_NOTICE,
  RESPECT_STORAGE_NOTICE,
  type RespectEntry,
  type RespectRiskLevel,
  respectEntryLabels,
} from '@/data/workplaceRespectQuestions';
import { decodeRespectResponse, type DecodedRespectResponse } from '@/diagnostics/workplace-respect/response';
import { getRespectHelpCalls, respectHelpCalls as CALLS } from '@/diagnostics/workplace-respect/help';

function removeStoredResult(key: string) {
  try { sessionStorage.removeItem(key); } catch { /* 저장소 사용 불가 */ }
}

const levelStyle: Record<RespectRiskLevel, { label: string; className: string }> = {
  low: {
    label: '낮음',
    className: 'bg-[var(--color-success-soft)] text-[#047857]',
  },
  caution: {
    label: '주의',
    className: 'bg-[var(--color-warning-soft)] text-[#92400e]',
  },
  high: {
    label: '높음',
    className: 'bg-[var(--color-warning-soft)] text-[#9a3412]',
  },
  urgent: {
    label: '즉시 도움 필요',
    className: 'bg-[#fff1f2] text-[#be123c]',
  },
};

const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary-accent)] focus-visible:ring-offset-2';
const dangerFocusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#be123c] focus-visible:ring-offset-2';
interface CallLink {
  href: string;
  number: string;
  label: string;
  sheetPrompt: string;
}

const quietButton = `min-h-[48px] rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-bg)] px-2 text-center text-[14px] font-semibold text-[var(--color-text-secondary)] hover:bg-[var(--color-card)] ${focusRing}`;
const softPrimaryButton = `min-h-[48px] rounded-[var(--radius-md)] border border-[var(--color-primary-muted)] bg-[var(--color-bg)] px-2 text-center text-[14px] font-semibold text-[var(--color-primary)] hover:bg-[var(--color-primary-soft)] ${focusRing}`;
const strongButton = `min-h-[48px] rounded-[var(--radius-md)] bg-[var(--color-primary)] px-2 text-center text-[14px] font-semibold text-white hover:bg-[var(--color-primary-hover)] ${focusRing}`;

type StoredRespectResult = DecodedRespectResponse;

interface RespectChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

type RespectChatErrorType = 'network' | 'rate-limit' | 'shared-rate-limit' | 'server';

export default function RespectResultClient({ entry }: { entry: RespectEntry }) {
  const router = useRouter();
  const [stored, setStored] = useState<StoredRespectResult | null | undefined>(undefined);
  const [showAiChat, setShowAiChat] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<RespectChatMessage[]>([]);
  const [streamingAnswer, setStreamingAnswer] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [chatErrorType, setChatErrorType] = useState<RespectChatErrorType | null>(null);
  const [piiWarning, setPiiWarning] = useState<string[] | null>(null);
  const chatAbortRef = useRef<AbortController | null>(null);
  const chatScrollAnchorRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const storageKey = useMemo(() => getRespectResultStorageKey(entry), [entry]);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(storageKey);
      if (!raw) {
        setStored(null);
        return;
      }

      const decoded = decodeRespectResponse(JSON.parse(raw), entry);
      if (!decoded) {
        removeStoredResult(storageKey);
        setStored(null);
        return;
      }

      setStored(decoded);
    } catch {
      removeStoredResult(storageKey);
      setStored(null);
    }
  }, [entry, storageKey]);

  useEffect(() => {
    if (!stored) return;
    const expiresAt = stored.response.createdAt + RESPECT_RESULT_TTL_MS;
    const expire = () => {
      if (Date.now() < expiresAt) return;
      chatAbortRef.current?.abort();
      removeStoredResult(storageKey);
      setChatMessages([]);
      setStreamingAnswer('');
      setShowAiChat(false);
      setStored(null);
    };
    const timer = setTimeout(expire, Math.max(0, expiresAt - Date.now()));
    document.addEventListener('visibilitychange', expire);
    return () => { clearTimeout(timer); document.removeEventListener('visibilitychange', expire); };
  }, [stored, storageKey]);

  useEffect(() => {
    return () => chatAbortRef.current?.abort();
  }, [chatAbortRef]);

  useEffect(() => {
    if (stored === null) {
      router.replace('/');
    }
  }, [router, stored]);

  useEffect(() => {
    if (!chatLoading) return;
    const interval = setInterval(() => {
      chatScrollAnchorRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 400);
    return () => clearInterval(interval);
  }, [chatLoading]);

  const result = useMemo(() => {
    if (!stored) return null;
    return calculateRespectResult(entry, stored.answers);
  }, [entry, stored]);
  const clearStoredResult = useCallback(() => {
    removeStoredResult(storageKey);
    setStored(null);
  }, [storageKey]);
  const clearAndGo = useCallback((href: string) => {
    clearStoredResult();
    router.push(href);
  }, [clearStoredResult, router]);
  const openAiChat = useCallback(() => {
    setShowAiChat(true);
    setTimeout(() => {
      textareaRef.current?.focus();
    }, 200);
  }, []);
  const fetchAiChat = useCallback(async () => {
    const question = chatInput.trim();
    if (!stored || !question) return;

    chatAbortRef.current?.abort();
    const controller = new AbortController();
    chatAbortRef.current = controller;
    setStreamingAnswer('');
    setChatErrorType(null);
    setPiiWarning(null);
    setChatLoading(true);

    let fullAnswer = '';

    try {
      const res = await fetch('/api/respect-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getClientIdHeader() },
        body: JSON.stringify({
          entry,
          response: stored.response,
          question,
          // 서버 본문 한도(64KB) 안에 들도록 최근 대화부터 글자 수 한도까지만 보낸다.
          history: chatMessages.length > 0 ? trimHistoryToLimit(chatMessages, RESPECT_MAX_HISTORY_MESSAGES) : undefined,
        }),
        signal: controller.signal,
      });

      if (res.status === 429) {
        const body = await res.json().catch(() => ({}));
        setChatErrorType(body.limitedBy === 'ip' ? 'shared-rate-limit' : 'rate-limit');
        return;
      }

      if (!res.ok || !res.body) {
        setChatErrorType('server');
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let lastRenderTime = 0;
      let completed = false;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data: ')) continue;
          const payload = trimmed.slice(6);
          if (payload === '[DONE]') {
            completed = true;
            continue;
          }

          let parsed: { token?: string; error?: string; pii_warning?: string[] };
          try { parsed = JSON.parse(payload); } catch { continue; }
          if (parsed.pii_warning) {
            setPiiWarning(parsed.pii_warning);
            continue;
          }
          if (parsed.error) {
            setChatErrorType('server');
            return;
          }
          if (parsed.token) {
            fullAnswer += parsed.token;
            const now = performance.now();
            if (now - lastRenderTime > 30) {
              setStreamingAnswer(fullAnswer);
              lastRenderTime = now;
            }
          }
        }
      }

      // 종료 신호 없이 끊긴 부분 답변은 대화에 저장하지 않는다.
      if (!fullAnswer.trim() || !completed) {
        setChatErrorType('server');
        return;
      }

      setStreamingAnswer(fullAnswer);
      setChatMessages((prev) => {
        const next: RespectChatMessage[] = [
          ...prev,
          { role: 'user', content: question },
          { role: 'assistant', content: fullAnswer },
        ];
        const trimCount = next.length - RESPECT_MAX_HISTORY_MESSAGES;
        return trimCount > 0 ? next.slice(trimCount) : next;
      });
      setChatInput('');
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') return;
      setChatErrorType(error instanceof TypeError ? 'network' : 'server');
    } finally {
      setChatLoading(false);
    }
  }, [chatInput, chatMessages, entry, stored]);
  const abortAiChat = useCallback(() => {
    chatAbortRef.current?.abort();
    setChatLoading(false);
  }, []);

  if (stored === undefined) {
    return <div className="min-h-[60vh]" />;
  }

  if (!stored || !result) {
    return <div className="min-h-[60vh]" />;
  }

  const entryLabel = respectEntryLabels[entry];
  const level = levelStyle[result.level];
  const notices = [result.safetyNotice, result.supportNotice].filter((notice) => notice !== null);
  // Safety or self-harm answers turn the screen into a help-first layout: one call leads, workplace detail folds away.
  const helpFirst = notices.length > 0;
  const crisisCalls = getRespectHelpCalls(result);
  const helpCalls: CallLink[] = getRespectHelpCalls(result);
  const [primaryCall, ...secondaryCalls] = helpCalls;
  const sheetCall = result.crisis
    ? (result.crisisKinds.includes('selfHarm') ? CALLS.rescue : CALLS.police)
    : helpFirst ? primaryCall : null;
  const workplaceSummary = result.axisSummary.activeAxes.length > 0 || !result.supportNotice ? result.summary : null;
  const supportLines = result.supportNotice ? [] : result.supportActions;
  const buttonGridCols = AI_CHAT_ENABLED ? 'grid-cols-2' : 'grid-cols-1';
  const containerClassName = 'animate-fade-in -mx-6 -mb-6 -mt-4 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-6 pb-5 pt-4 sm:-mx-6 sm:-mb-8 sm:-mt-6 sm:px-6 sm:pb-6 sm:pt-5';
  const heroClassName = 'relative shrink-0 overflow-hidden rounded-[var(--radius-lg)] bg-[var(--color-primary-soft)] px-5 py-5';
  const cardClassName = 'shrink-0 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-card)] px-4 py-3.5';
  const bodyTextClassName = 'text-[14px] leading-relaxed text-[var(--color-text-secondary)]';
  const aiQuestionPlaceholder = result.crisis && entry === 'experience'
    ? '도움을 요청할 문장이나 지금 할 일을 짧게 물어보세요'
    : '결과를 바탕으로 더 궁금한 점을 질문하세요';

  const heroArt = (
    <LeafLineArt className="pointer-events-none absolute -right-10 -top-8 h-40 w-40 text-[var(--color-primary-muted)]" />
  );
  const actionList = (items: string[]) => (
    <ul className="mt-2 space-y-1.5">
      {items.map((item) => (
        <li key={item} className="flex gap-2 text-[14px] leading-relaxed text-[var(--color-text)]">
          <span aria-hidden="true" className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--color-primary)]" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
  const footerButtons = (
    <div className="mt-auto shrink-0 space-y-3 pt-1">
    <p className="text-[12px] leading-relaxed text-[var(--color-text-secondary)]">{RESPECT_RESULT_NOTICE}</p>
    {AI_CHAT_ENABLED && <p className="text-[12px] leading-relaxed text-[var(--color-text-secondary)]">AI 질문을 보내면 응답·질문·최근 대화가 외부 AI 제공사로 전송됩니다. 개인을 알아볼 정보는 적지 마세요.</p>}
    <details className="text-[12px] leading-relaxed text-[var(--color-text-secondary)]">
      <summary className={`cursor-pointer rounded py-2 ${focusRing}`}>응답 저장·AI 전송 안내</summary>
      <p className="mt-1">{RESPECT_STORAGE_NOTICE}</p>
      <p className="mt-1">이 점검의 응답만으로 기관에 자동 신고하지 않습니다. 상담·신고 절차와 비밀보장 범위는 이용할 창구에 확인하세요.</p>
    </details>
    <div className={`grid ${buttonGridCols} gap-2`}>
      <button type="button" onClick={() => clearAndGo('/')} className={quietButton}>
        처음으로
      </button>
      {AI_CHAT_ENABLED && (
        <button type="button" onClick={openAiChat} className={helpFirst || result.crisis ? softPrimaryButton : strongButton}>
          AI 조언
        </button>
      )}
    </div>
    </div>
  );
  const aiChatSheet = showAiChat ? (
    <AiAdviceSheet
      loading={chatLoading}
      messages={chatMessages}
      currentUserMessage={chatInput.trim()}
      streamingAnswer={streamingAnswer}
      inputValue={chatInput}
      onInputChange={setChatInput}
      onSubmit={fetchAiChat}
      onAbort={abortAiChat}
      onClose={() => {
        if (!chatLoading) {
          setShowAiChat(false);
        }
      }}
      onDeleteConversation={() => {
        setChatMessages([]);
        setStreamingAnswer('');
        setChatInput('');
        setChatErrorType(null);
        setPiiWarning(null);
        setTimeout(() => textareaRef.current?.focus(), 100);
      }}
      inputRef={textareaRef}
      scrollAnchorRef={chatScrollAnchorRef}
      placeholder={aiQuestionPlaceholder}
      errorType={chatErrorType}
      piiWarning={piiWarning}
      helpAction={sheetCall ? {
        href: sheetCall.href,
        label: `${sheetCall.number} 전화`,
        ariaLabel: `${sheetCall.number} 전화, ${sheetCall.label}`,
        description: sheetCall.sheetPrompt,
      } : null}
    />
  ) : null;

  if (result.crisis) {
    return (
      <>
      <div className={containerClassName}>
        <header className={heroClassName}>
          {heroArt}
          <h1 className="relative text-[1.5rem] font-extrabold leading-snug tracking-tight text-[var(--color-text)] [word-break:keep-all]">
            {result.title}
          </h1>
          <p className="relative mt-1 text-[13px] text-[var(--color-text-secondary)]">{entryLabel.title}</p>
          <p className={`relative mt-3 ${bodyTextClassName}`}>{result.summary}</p>
          <div className={`relative mt-4 grid gap-2 ${crisisCalls.length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
            {crisisCalls.map((link) => (
              <a
                key={link.href}
                href={link.href}
                aria-label={`${link.number} ${link.label} 전화`}
                className={`flex min-h-[56px] flex-col items-center justify-center rounded-[var(--radius-md)] bg-[#be123c] px-2 text-white hover:bg-[#9f1239] ${dangerFocusRing}`}
              >
                <span className="text-[17px] font-bold leading-tight">{link.number}</span>
                <span className="text-[12px] font-medium leading-tight">{link.label}</span>
              </a>
            ))}
          </div>
        </header>

        <section className={cardClassName}>
          <h2 className="text-[15px] font-bold text-[var(--color-text)]">바로 할 일</h2>
          {actionList(result.primaryActions)}
          {result.supportActions.length > 0 && (
            <p className="mt-3 border-t border-[var(--color-border)] pt-3 text-[13px] leading-relaxed text-[var(--color-text-secondary)]">
              {result.supportActions.join(' ')}
            </p>
          )}
        </section>

        {footerButtons}
      </div>
      {aiChatSheet}
      </>
    );
  }

  const workplaceContent = (
    <>
      {workplaceSummary && <p className={`${bodyTextClassName} mb-3`}>{workplaceSummary}</p>}
      <h2 className="text-[15px] font-bold text-[var(--color-text)]">지금 할 일</h2>
      {actionList(result.primaryActions)}
      {supportLines.length > 0 && (
        <p className="mt-3 border-t border-[var(--color-border)] pt-3 text-[13px] leading-relaxed text-[var(--color-text-secondary)]">
          {supportLines.join(' ')}
        </p>
      )}
    </>
  );

  return (
    <>
    <div className={containerClassName}>
      <header className={heroClassName}>
        {heroArt}
        <h1 className="relative text-[1.5rem] font-extrabold leading-snug tracking-tight text-[var(--color-text)] [word-break:keep-all]">
          {result.title}
        </h1>
        <div className="relative mt-3 flex flex-wrap items-center gap-2 text-[13px] text-[var(--color-text-secondary)]">
          {!helpFirst && !result.informationLimited && (
            <span className={`rounded-full px-3 py-1 text-[12px] font-bold ${level.className}`}>
              <span className="sr-only">결과 수준 </span>{level.label}
            </span>
          )}
          <span>{entryLabel.title}</span>
        </div>
      </header>

      {helpFirst && (
        <section aria-labelledby="respect-help-title" className="shrink-0 rounded-[var(--radius-lg)] border border-[var(--color-primary-muted)] bg-[var(--color-bg)] px-4 py-4">
          {notices.map((notice, index) => (
            <div key={notice.title} className={index > 0 ? 'mt-3 border-t border-[var(--color-border)] pt-3' : undefined}>
              <h2 id={index === 0 ? 'respect-help-title' : undefined} className="text-[16px] font-bold text-[var(--color-text)]">
                {notice.title}
              </h2>
              <p className={`mt-1 ${bodyTextClassName}`}>{notice.body}</p>
            </div>
          ))}
          <a
            href={primaryCall.href}
            aria-label={`${primaryCall.number} ${primaryCall.label} 전화`}
            className={`mt-4 flex min-h-[52px] items-center justify-center gap-2 rounded-[var(--radius-md)] bg-[var(--color-primary)] px-3 text-white hover:bg-[var(--color-primary-hover)] ${focusRing}`}
          >
            <span className="text-[17px] font-bold">{primaryCall.number}</span>
            <span className="text-[14px] font-semibold">{primaryCall.label}</span>
          </a>
          <div className={`mt-2 grid gap-2 ${secondaryCalls.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
            {secondaryCalls.map((call) => (
              <a
                key={call.href}
                href={call.href}
                aria-label={`${call.number} ${call.label} 전화`}
                className={`flex min-h-[48px] items-center justify-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--color-primary-muted)] bg-[var(--color-bg)] px-2 text-[var(--color-primary)] hover:bg-[var(--color-primary-soft)] ${focusRing}`}
              >
                <span className="text-[15px] font-bold">{call.number}</span>
                <span className="text-[13px] font-medium">{call.label}</span>
              </a>
            ))}
          </div>
        </section>
      )}

      {helpFirst ? (
        <details className={`group ${cardClassName}`}>
          <summary className={`-mx-1 flex min-h-[44px] cursor-pointer list-none items-center justify-between gap-2 rounded-[var(--radius-md)] px-1 text-[15px] font-bold text-[var(--color-text)] [&::-webkit-details-marker]:hidden ${focusRing}`}>
            일터 상황 정리 보기
            <svg aria-hidden="true" viewBox="0 0 20 20" fill="none" className="h-4 w-4 shrink-0 text-[var(--color-text-secondary)] transition-transform group-open:rotate-180">
              <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </summary>
          <div className="mt-2"><p className="mb-3 text-[13px] leading-relaxed text-[var(--color-text-secondary)]">안전을 확인하고 도움을 연결한 뒤 살펴볼 수 있습니다.</p>{workplaceContent}</div>
        </details>
      ) : (
        <section className={cardClassName}>{workplaceContent}</section>
      )}

      {footerButtons}
    </div>
    {aiChatSheet}
    </>
  );
}
