import type { RespectChoice, RespectEntry, RespectQuestion, RespectRiskAxis } from './types';

export const RESPECT_QUESTION_VERSION = 'v0.2.2';
export const RESPECT_INSTRUMENT_VERSION = 'workplace-respect-v0.2.2';
export const RESPECT_SCORING_VERSION = 'workplace-respect-risk-v0.2.2';
export const RESPECT_RESULT_STORAGE_KEY = 'workplace-respect-result';
export const RESPECT_RESULT_TTL_MS = 30 * 60 * 1000;
export const RESPECT_SITUATION_GUIDANCE = '점검할 한 사건이나 이어지는 상황 하나와 관련된 상대를 떠올려주세요. 상대는 한 사람 또는 집단일 수 있습니다. 시작부터 끝까지, 진행 중이면 지금까지를 기준으로 답해주세요. 해당하지 않으면 해당 없음이나 없음을, 판단하기 어려우면 판단하기 어려움을 선택하세요. 정도를 고르는 문항은 가장 가까운 응답을 선택하세요.';
export const RESPECT_START_NOTICE = '기관 내부의 업무 관계를 돌아보는 자가점검이며 공식 판정이나 진단이 아닙니다. 이름·소속 등 식별정보를 묻지 않습니다. 먼저 현재 안전과 도움 필요를 확인합니다. 도움 경로는 점검을 끝내지 않아도 볼 수 있습니다.';
export const RESPECT_RESULT_NOTICE = '법적 판단이나 진단이 아닙니다. 안내 수준이나 기록 유무와 관계없이 상담과 보호 조치를 문의할 수 있습니다.';
export const RESPECT_STORAGE_NOTICE = '응답·결과는 이 탭의 브라우저 저장소에 30분의 보관 기한을 두며, 결과를 다시 열 때도 만료를 확인합니다. 결과 화면의 처음으로 버튼을 누르면 삭제합니다. AI 조언을 요청하면 응답·질문·최근 대화가 서버를 거쳐 외부 AI 제공사로 전송됩니다. 이름·소속·사건 당사자를 알아볼 정보는 적지 마세요.';
export const respectEntryLabels: Record<RespectEntry, { title: string; shortTitle: string; description: string }> = {
  action: { title: '내 행동 점검', shortTitle: '내 행동', description: '내 말이나 지시가 상대에게 준 부담을 돌아봅니다.' },
  experience: { title: '일터 존중 점검', shortTitle: '존중 점검', description: '내가 겪은 일을 정리하고 기록·상담·도움 경로를 살펴봅니다.' },
};
export const respectAxisLabels: Record<RespectRiskAxis, string> = {
  relationPower: '거절하기 어려운 관계', workScope: '업무범위·방식의 적정성', dignityHarm: '존중을 해치는 말·행동 또는 일상 영향',
  privateBenefit: '사적 요구', disadvantage: '평가·인사·업무배정의 불이익', repetition: '반복성',
};
const agreement: RespectChoice[] = [
  { id: 'no', text: '아니다 / 해당하지 않는다', score: 0 },
  { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
  { id: 'yes', text: '그렇다', score: 2 }, { id: 'strong', text: '매우 그렇다', score: 3 },
];
// Occurrence items: 2 = it happened, 3 = it was severe. Frequency belongs to the repetition items.
function occurrence(present: string, severe: string): RespectChoice[] {
  return [
    { id: 'no', text: '아니다 / 해당하지 않는다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
    { id: 'present', text: `${present} (아래 정도까지는 아니다)`, score: 2 }, { id: 'severe', text: severe, score: 3 },
  ];
}
const intensity: RespectChoice[] = [
  { id: 'no', text: '아니다 / 해당하지 않는다', score: 0 }, { id: 'mild', text: '조금 과도했다', score: 1 },
  { id: 'clear', text: '상당히 과도했다', score: 2 }, { id: 'strong', text: '매우 과도했다', score: 3 },
];
const repetition: RespectChoice[] = [
  { id: 'notRepeated', text: '없거나 한 번뿐이었다', score: 0 },
  { id: 'uncertain', text: '반복 여부를 모르겠다', score: 0, uncertain: true },
  { id: 'sometimes', text: '가끔 반복됐다', score: 2 }, { id: 'often', text: '자주 반복됐다', score: 3 },
];
const relevance: RespectChoice[] = [
  { id: 'necessary', text: '업무상 필요한 이유가 있었다', score: 0 }, { id: 'partlyNecessary', text: '업무상 필요한 이유가 일부 있었다', score: 1 },
  { id: 'barelyNecessary', text: '업무상 필요한 이유가 거의 없었다', score: 2 }, { id: 'unnecessary', text: '업무상 필요한 이유가 없었다', score: 3 },
  { id: 'noRequest', text: '요청이나 지시가 없었다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
];
function question(value: RespectQuestion): RespectQuestion {
  return { ...value, choices: value.choices.map((choice) => ({ ...choice, id: `${value.id}:${choice.id}` })) };
}
export const workplaceRespectRuntimeQuestions: RespectQuestion[] = [
  question({ id: 'A01', entry: 'action', category: '관계', axis: 'relationPower', prompt: '직위·평가 권한, 고용 형태, 연령·근속·전문성, 인원수 같은 차이 때문에 상대가 내 요청이나 의견을 거절하기 어려웠나요?', choices: agreement }),
  question({ id: 'A02', entry: 'action', category: '업무범위', axis: 'workScope', prompt: '내 요청이나 지시에 업무상 필요한 이유가 있었나요? 평소 담당 업무 외의 협업·임시 업무도 포함합니다.', choices: relevance }),
  question({ id: 'A03', entry: 'action', category: '업무범위', axis: 'workScope', prompt: '업무 관련 여부와 별개로, 내가 요청한 시간·방식·표현이 과도했나요?', choices: intensity }),
  question({ id: 'A04', entry: 'action', category: '사적요구', axis: 'privateBenefit', prompt: '내 개인 편의를 위한 부탁이나 업무와 무관한 심부름을 요구했나요?', choices: occurrence('요구한 적이 있다', '시간·비용 부담이 큰 요구였다') }),
  question({ id: 'A05', entry: 'action', category: '존중', axis: 'dignityHarm', prompt: '근무시간 외 연락, 휴가 중 업무 요청, 사생활 간섭처럼 상대의 휴식이나 사생활에 부담을 주었나요?', choices: occurrence('그런 적이 있다', '휴식이나 사생활에 큰 지장을 줬다') }),
  question({ id: 'A06', entry: 'action', category: '존중', axis: 'dignityHarm', prompt: '나는 상대에게 모욕·비하·위협으로 받아들여질 수 있는 말이나 행동을 했나요? 공개된 자리, 1:1 대화, 메신저를 모두 포함합니다.', choices: occurrence('그런 말이나 행동을 했다', '상대에게 큰 모욕감이나 위협을 줄 수 있는 말이나 행동을 했다') }),
  question({ id: 'A07', entry: 'action', category: '불이익', axis: 'disadvantage', prompt: '상대의 거절·질문·문제 제기에 평가, 인사, 업무배정의 불이익을 암시하거나 실제로 줬나요?', choices: [
    { id: 'no', text: '아니다 / 그런 상황이 없었다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
    { id: 'implied', text: '불이익을 암시했다', score: 2 }, { id: 'occurred', text: '실제 불이익을 줬다', score: 3 },
  ] }),
  question({ id: 'A08', entry: 'action', category: '반복', axis: 'repetition', prompt: '같은 상대에게 앞에서 떠올린 부담을 줄 수 있는 말·요구·대우가 반복됐나요?', choices: repetition }),
  question({ id: 'A09', entry: 'action', category: '존중', axis: 'dignityHarm', prompt: '상대가 불편함을 표현한 뒤에도 나는 같은 요구를 계속했나요?', choices: [
    { id: 'no', text: '아니다 / 불편함을 표현한 상황이 없었다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
    { id: 'some', text: '한두 번 더 요구했다', score: 2 }, { id: 'continued', text: '계속 요구했다', score: 3 },
  ] }),
  question({ id: 'A12', entry: 'action', category: '업무범위', axis: 'workScope', prompt: '정당한 업무 이유 없이 상대를 정보·회의·업무에서 배제하거나, 일을 주지 않거나, 능력·경력과 동떨어진 단순 업무만 맡겼나요?', choices: occurrence('그런 적이 있다', '업무 수행이 어려울 만큼 심했다') }),
  question({ id: 'A10', entry: 'action', category: '확인', axis: 'resultGate', prompt: '이 행동을 멈추고 제3자에게 기준을 확인할 필요가 있다고 느끼나요?', choices: [
    { id: 'no', text: '아니다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
    { id: 'review', text: '확인이 필요하다', score: 0, gate: true }, { id: 'stop', text: '지금 멈추고 확인해야 한다', score: 0, gate: true },
  ] }),
  question({ id: 'A11', entry: 'action', category: '안전', axis: 'crisisGate', prompt: '내 말이나 행동 때문에 지금 누군가의 신체 안전이 위험하거나, 이미 폭력·상해가 있었나요?', choices: [
    { id: 'safe', text: '아니다', score: 0 }, { id: 'uncertain', text: '안전한지 확신하기 어렵다', score: 0, gate: true, uncertain: true },
    { id: 'imminent', text: '폭력이나 위협을 가할 것 같다', score: 0, crisis: true, crisisKind: 'physicalSafety' },
    { id: 'occurred', text: '이미 폭력이 있었거나 다친 사람이 있다', score: 0, crisis: true, crisisKind: 'physicalSafety' },
  ] }),
  question({ id: 'E01', entry: 'experience', category: '관계', axis: 'relationPower', prompt: '직위·평가 권한, 고용 형태, 연령·근속·전문성, 인원수 같은 차이 때문에 상대의 요구나 의견을 거절하기 어려웠나요?', choices: agreement }),
  question({ id: 'E02', entry: 'experience', category: '업무범위', axis: 'workScope', prompt: '상대의 요청이나 지시에 업무상 필요한 이유가 있었나요? 평소 담당 업무 외의 협업·임시 업무도 포함합니다.', choices: relevance }),
  question({ id: 'E03', entry: 'experience', category: '업무범위', axis: 'workScope', prompt: '업무 관련 여부와 별개로, 상대의 행동 방식·시간·강도가 과도했나요?', choices: intensity }),
  question({ id: 'E04', entry: 'experience', category: '사적요구', axis: 'privateBenefit', prompt: '상대의 개인 편의를 위한 부탁이나 업무와 무관한 심부름을 요구받았나요?', choices: occurrence('요구받은 적이 있다', '시간·비용 부담이 큰 요구였다') }),
  question({ id: 'E05', entry: 'experience', category: '존중', axis: 'dignityHarm', prompt: '모욕·비하·위협으로 받아들여질 수 있는 말이나 행동이 있었나요? 공개된 자리, 1:1 대화, 메신저를 모두 포함합니다.', choices: [
    { id: 'no', text: '없었다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
    { id: 'present', text: '있었다 (아래 정도까지는 아니다)', score: 2 }, { id: 'severe', text: '큰 모욕감이나 위협을 느낄 정도였다', score: 3 },
  ] }),
  question({ id: 'E06', entry: 'experience', category: '존중', axis: 'dignityHarm', prompt: '그 상황 이후 출근, 업무수행, 수면, 불안, 대인관계에 새로 생기거나 심해진 영향이 있었나요? 가장 큰 영향을 기준으로 답해주세요.', choices: [
    { id: 'no', text: '없었다', score: 0 }, { id: 'mild', text: '조금 있었다', score: 1 },
    { id: 'clear', text: '상당히 있었다', score: 2 }, { id: 'disrupted', text: '일상에 지장이 있었다', score: 3 },
  ] }),
  question({ id: 'E07', entry: 'experience', category: '불이익', axis: 'disadvantage', prompt: '거절·질문·문제 제기를 이유로 상대가 평가, 인사, 업무배정의 불이익을 암시하는 말이나 행동을 했거나 실제 불이익이 있었나요?', choices: [
    { id: 'no', text: '아니다 / 그런 상황이 없었다', score: 0 }, { id: 'uncertain', text: '판단하기 어렵다', score: 0, uncertain: true },
    { id: 'implied', text: '불이익을 암시하는 말이나 행동이 있었다', score: 2 }, { id: 'occurred', text: '실제 불이익이 있었다', score: 3 },
    { id: 'concern', text: '그런 말이나 행동은 없었지만 불이익이 걱정된다', score: 0, gate: true, concern: true },
  ] }),
  question({ id: 'E08', entry: 'experience', category: '반복', axis: 'repetition', prompt: '같은 상대에게서 앞에서 떠올린 부담스럽거나 부당하다고 느낀 말·요구·대우가 반복됐나요?', choices: repetition }),
  question({ id: 'E09', entry: 'experience', category: '기록', axis: 'evidenceSupport', prompt: '문자, 메신저, 이메일, 일정 등 상황을 확인할 기록이 있나요?', choices: [
    { id: 'none', text: '없다', score: 0 }, { id: 'some', text: '일부 있다', score: 0 }, { id: 'most', text: '대부분 있다', score: 0 }, { id: 'several', text: '여러 종류로 충분히 있다', score: 0 },
  ] }),
  question({ id: 'E10', entry: 'experience', category: '안전', axis: 'crisisGate', prompt: '지금 스스로를 해칠 생각이 들거나 이미 스스로를 해친 상태인가요?', choices: [
    { id: 'no', text: '없다', score: 0 }, { id: 'passing', text: '생각이 잠깐 스치지만 지금 실행할 생각은 없다', score: 0, support: true, supportKind: 'passing' },
    { id: 'recurring', text: '생각이 반복되거나 그 생각을 혼자 감당하기 어렵다', score: 0, support: true, supportKind: 'recurring' },
    { id: 'immediate', text: '지금 실행할 것 같거나 이미 다쳐 즉시 도움이 필요하다', score: 0, crisis: true, crisisKind: 'selfHarm' },
  ] }),
  question({ id: 'E11', entry: 'experience', category: '안전', axis: 'crisisGate', prompt: '다른 사람의 폭력이나 위협으로 지금 내 신체 안전이 위험하거나, 이미 다쳤나요?', choices: [
    { id: 'safe', text: '아니다', score: 0 }, { id: 'uncertain', text: '안전한지 확신하기 어렵다', score: 0, gate: true, uncertain: true },
    { id: 'imminent', text: '폭력이나 위협이 진행 중이거나 곧 일어날 것 같다', score: 0, crisis: true, crisisKind: 'physicalSafety' },
    { id: 'injured', text: '이미 다쳤거나 즉시 보호가 필요하다', score: 0, crisis: true, crisisKind: 'physicalSafety' },
  ] }),
  question({ id: 'E12', entry: 'experience', category: '업무범위', axis: 'workScope', prompt: '정당한 업무 이유 없이 정보·회의·업무에서 배제되거나, 일을 받지 못하거나, 능력·경력과 동떨어진 단순 업무만 맡았나요?', choices: occurrence('그런 일이 있었다', '업무 수행이 어려울 만큼 심했다') }),
];
export function getRespectQuestions(entry: RespectEntry): RespectQuestion[] {
  const safetyFirst = entry === 'action' ? ['A11'] : ['E11', 'E10'];
  const priority = (id: string) => safetyFirst.includes(id) ? safetyFirst.indexOf(id) : safetyFirst.length;
  return workplaceRespectRuntimeQuestions.filter((item) => item.entry === entry).sort((a, b) => priority(a.id) - priority(b.id));
}
// The situation guidance anchors the risk items, so it appears with the first non-safety question.
export function getRespectSituationGuidanceIndex(entry: RespectEntry): number {
  return getRespectQuestions(entry).findIndex((item) => item.category !== '안전');
}
export function isRespectEntry(value: string | null): value is RespectEntry { return value === 'action' || value === 'experience'; }
export function buildRespectCheckUrl(entry: RespectEntry): string { return `/respect/check?entry=${entry}`; }
export function buildRespectResultUrl(entry: RespectEntry): string { return `/respect/result?entry=${entry}`; }
export function getRespectResultStorageKey(entry: RespectEntry): string { return `${RESPECT_RESULT_STORAGE_KEY}:${entry}`; }
