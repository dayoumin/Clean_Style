import { getRespectQuestions, respectAxisLabels } from './content';
import type { RespectAxisSummary, RespectCrisisKind, RespectEntry, RespectResult, RespectRiskAxis, RespectRiskLevel, RespectSupportKind } from './types';

const riskAxes: RespectRiskAxis[] = ['relationPower', 'workScope', 'dignityHarm', 'privateBenefit', 'disadvantage', 'repetition'];
function emptyAxes(): Record<RespectRiskAxis, number> {
  return { relationPower: 0, workScope: 0, dignityHarm: 0, privateBenefit: 0, disadvantage: 0, repetition: 0 };
}
export function calculateRespectResult(entry: RespectEntry, answers: number[]): RespectResult {
  const questions = getRespectQuestions(entry);
  const scores = emptyAxes();
  const crisisKinds = new Set<RespectCrisisKind>();
  let score = 0, answeredCount = 0, uncertainCount = 0;
  let support = false, resultGate = false, strongSignal = false, improperTreatment = false;
  let supportKind: RespectSupportKind | null = null;
  let safetyUncertain = false;
  let retaliationConcern = false;
  let stopRequested = false;
  const flaggedItems: string[] = [];
  answers.slice(0, questions.length).forEach((answer, index) => {
    if (!Number.isInteger(answer)) return;
    const item = questions[index];
    const choice = item?.choices[answer];
    if (!choice) return;
    answeredCount++;
    // Safety uncertainty has its own notice; other unknown answers never imply absence of risk.
    if (choice.uncertain && item.axis !== 'crisisGate') uncertainCount++;
    if (riskAxes.includes(item.axis as RespectRiskAxis)) {
      const axis = item.axis as RespectRiskAxis;
      scores[axis] = Math.max(scores[axis], choice.score);
      // Relation and repetition describe context, not a problematic act, so they cannot raise the level alone.
      strongSignal ||= choice.score >= 3 && axis !== 'relationPower' && axis !== 'repetition';
      if (['A06', 'E05', 'A12', 'E12'].includes(item.id) && choice.score >= 2) improperTreatment = true;
      if (choice.score >= 2) flaggedItems.push(item.id);
    }
    if (choice.crisis) crisisKinds.add(choice.crisisKind ?? 'physicalSafety');
    support ||= Boolean(choice.support);
    if (choice.supportKind && supportKind !== 'recurring') supportKind = choice.supportKind;
    resultGate ||= Boolean(choice.gate);
    safetyUncertain ||= item.axis === 'crisisGate' && Boolean(choice.gate);
    retaliationConcern ||= Boolean(choice.concern);
    stopRequested ||= choice.id === 'A10:stop';
  });
  // An axis requires one clearly endorsed item; two mild answers do not activate it.
  score = riskAxes.reduce((total, axis) => total + scores[axis], 0);
  const activeAxes = riskAxes.filter((axis) => scores[axis] >= 2);
  const active = new Set(activeAxes);
  // Unvalidated pilot signal combination, not evidence that legal elements are satisfied.
  const consultationSignalsMet = active.has('relationPower')
    && (active.has('workScope') || active.has('privateBenefit') || active.has('disadvantage') || improperTreatment)
    && (active.has('dignityHarm') || active.has('disadvantage') || active.has('repetition'));
  const substantiveSignal = activeAxes.some(axis => axis !== 'relationPower' && axis !== 'repetition');
  const relationWithSignal = active.has('relationPower') && substantiveSignal;
  const axisSummary: RespectAxisSummary = { scores, activeAxes, consultationSignalsMet };
  const crisis = crisisKinds.size > 0;
  // Provisional guidance thresholds, not legal or clinical classifications.
  const level: RespectRiskLevel = crisis ? 'urgent'
    : consultationSignalsMet && score >= 8 ? 'high'
    : consultationSignalsMet || relationWithSignal || strongSignal || improperTreatment || active.has('dignityHarm') || active.has('disadvantage')
      || resultGate || support || (substantiveSignal && score >= 6) || activeAxes.length >= 3 ? 'caution' : 'low';
  const informationLimited = level === 'low' && uncertainCount > 0;
  const content = buildContent(entry, level, axisSummary, supportKind, [...crisisKinds], uncertainCount, flaggedItems);
  return { entry, level, score, crisis, crisisKinds: [...crisisKinds], support, supportKind, safetyUncertain, answeredCount, uncertainCount, informationLimited, retaliationConcern, axisSummary,
    ...content,
    ...(!crisis && stopRequested ? { primaryActions: ['해당 요청이나 표현을 지금 멈추고 제3자에게 기준을 확인하세요.', ...content.primaryActions].slice(0, 3) } : {}),
    ...(informationLimited ? { title: '판단하기 어려운 부분을 확인해 보세요', summary: '판단하기 어렵다는 응답이 포함되어 있어 낮은 위험으로 해석할 수 없습니다. 확인할 사실을 정리하고 필요하면 상담을 이용하세요.' } : {}),
    ...(!crisis && retaliationConcern && !substantiveSignal ? { summary: '불이익이 걱정된다는 응답입니다. 실제 불이익 행위가 확인되었다는 뜻은 아닙니다. 안전한 내부·외부 상담창구에서 우려와 필요한 보호를 이야기할 수 있습니다.' } : {}),
    safetyNotice: !crisis && safetyUncertain ? safetyContent[entry] : null };
}

const supportContent: Record<RespectSupportKind, { summary: string; title: string; actions: string[]; notice: { title: string; body: string } }> = {
  passing: {
    summary: '마음건강 도움 신호를 선택했습니다. 일터 상황의 판단과 별개로 지금 상태를 살피고 도움을 받을 경로를 확인하세요.',
    title: '지금 상태와 도움 경로를 확인하세요',
    actions: ['가까운 신뢰할 수 있는 사람에게 현재 상태를 알리고 정신건강복지센터나 109 상담에 연결하세요. 즉시 위험해지면 119 등 긴급 도움을 요청하세요.'],
    notice: {
      title: '도움받을 수 있는 곳',
      body: '스치는 생각이라도 혼자 감당하지 않아도 됩니다. 빈도만으로 현재 안전을 판단하지 않습니다. 가까운 사람이나 109 자살예방상담전화에 지금 상태를 알려주세요. 지금 실행할 것 같거나 다쳐 응급 도움이 필요하면 119에 연결하세요.',
    },
  },
  // Frequency does not establish safety or an appropriate clinical response deadline.
  recurring: {
    summary: '마음건강 도움 신호 중 자해 생각이 반복되거나 혼자 감당하기 어렵다는 응답입니다. 이 응답만으로 현재 안전이나 위험 수준을 판단할 수 없습니다. 일터 점검보다 실제 사람과 도움을 연결하는 것이 먼저입니다.',
    title: '사람과 연결해 현재 상태를 확인하세요',
    actions: ['가까운 신뢰할 수 있는 사람에게 지금 상태를 알리고 109 자살예방상담전화에 연락하세요.', '지금 실행할 것 같거나 다쳐 응급 도움이 필요하면 119에 연결하세요.'],
    notice: {
      title: '도움받을 수 있는 곳',
      body: '혼자 감당하지 않아도 됩니다. 생각의 빈도만으로 현재 안전을 판단할 수 없습니다. 가까운 사람이나 109 자살예방상담전화에 지금 상태를 알려주세요. 지금 실행할 것 같거나 다쳐 응급 도움이 필요하면 119에 연결하세요.',
    },
  },
};

// A11/E11 "안전한지 확신하기 어렵다" stays non-urgent, but the result must still lead with physical safety.
const safetyContent: Record<RespectEntry, { title: string; body: string }> = {
  action: {
    title: '안전부터 확인하세요',
    body: '해당 말·연락·행동을 멈추고 상대와 거리를 두세요. 지금 폭력·위협 위험이 있으면 112, 상해로 응급 도움이 필요하면 119에 연결하세요. 안전을 확신하기 어렵다면 점검보다 믿을 수 있는 사람의 도움을 먼저 요청하세요.',
  },
  experience: {
    title: '안전부터 확인하세요',
    body: '상대와 거리를 두고 안전한 장소와 믿을 수 있는 사람을 먼저 확보하세요. 지금 폭력·위협 위험이 있으면 112, 상해로 응급 도움이 필요하면 119에 연결하세요. 안전을 확신하기 어렵다면 혼자 판단하지 말고 도움을 요청하세요.',
  },
};

// Actor advice follows the behaviours the person actually reported, most serious first.
const actionItemAdvice: Array<[string, string]> = [
  ['A06', '모욕·비하·위협으로 받아들여질 수 있는 표현을 멈추고, 필요하면 사실 중심으로 정정하세요.'],
  ['A07', '불이익을 암시한 말은 바로잡고 평가·업무배정 결정과 분리하세요.'],
  ['A12', '배제한 정보·회의·업무를 정당한 기준에 따라 다시 공유하고 배분하세요.'],
  ['A04', '사적인 부탁이나 업무 외 요구를 멈추고 업무 기준을 확인하세요.'],
  ['A09', '상대가 불편함을 표현한 요구는 멈추고 다른 방법을 함께 정하세요.'],
  ['A05', '근무시간 외 연락과 휴가 중 요청은 꼭 필요한 경우로 줄이고 기준을 미리 정하세요.'],
  ['A02', '요청이 상대의 업무에 필요한지 다시 확인하고, 아니라면 거두세요.'],
  ['A03', '요청한 시간·방식·표현에서 과도한 부분을 조정하세요.'],
];

function buildContent(entry: RespectEntry, level: RespectRiskLevel, axes: RespectAxisSummary, supportKind: RespectSupportKind | null, crisisKinds: RespectCrisisKind[], uncertainCount: number, flaggedItems: string[]) {
  if (level === 'urgent') {
    const selfHarm = crisisKinds.includes('selfHarm');
    return {
      title: '지금은 안전과 도움 연결이 먼저입니다',
      summary: selfHarm ? '지금 스스로를 해칠 수 있거나 이미 다쳤다는 응답입니다. 점검보다 실제 사람과 기관의 도움을 먼저 받아주세요.' : '폭력·위협·상해와 관련된 안전 우려를 선택했습니다. 지금도 위험하거나 다친 사람이 있다면 점검보다 안전한 거리와 실제 도움을 먼저 확보하세요.',
      primaryActions: entry === 'action'
        ? ['위협적인 말·연락·행동을 즉시 멈추고 상대와 거리를 두세요.', '상대에게 직접 해명이나 대면을 요구하지 말고 안전한 책임자에게 도움을 요청하세요.', '폭력 위험은 112, 상해·응급 상황은 119에 바로 연결하세요.']
        : selfHarm
          ? ['혼자 감당하지 말고 가까운 신뢰할 수 있는 사람에게 지금 상태를 알리세요.', '즉시 다칠 위험이 있거나 이미 다쳤다면 119에 연결하세요. 자해 생각의 상담은 109에서 도움을 받을 수 있습니다.', '다른 사람의 폭력 위험도 있으면 안전한 장소로 이동하고 112에 연결하세요.']
          : ['상대와 거리를 두고 안전한 장소로 이동하세요.', '폭력·위협은 112, 상해·응급 상황은 119에 바로 연결하세요.', '기관 내부 연락이 위험하거나 도움을 지연시키면 외부 도움을 먼저 요청하세요.'],
      supportActions: ['가까운 신뢰할 수 있는 사람이나 안전한 책임자에게 현재 상황과 필요한 보호를 알려주세요.'],
      supportNotice: null,
    };
  }
  const action = entry === 'action';
  const support = supportKind ? supportContent[supportKind] : null;
  const signals = axes.activeAxes.map((axis) => respectAxisLabels[axis]);
  const summary = signals.length > 0
    ? `응답에서 ${signals.join(', ')}에 관한 신호를 확인했습니다. ${action ? '표현과 요청을 돌아보고 필요하면 제3자에게 기준을 확인하세요.' : '상황을 기록하고 안전한 상담 경로를 살펴보세요.'}`
    : support ? support.summary
    : uncertainCount > 0 ? '판단하기 어렵다는 응답이 포함되어 있습니다. 불분명한 사실을 정리하고 필요하면 안전한 창구에 기준을 확인하세요.'
    : level === 'caution' ? '중단이나 기준 확인이 필요하다는 응답입니다. 상황을 정리하고 제3자에게 확인할 경로를 살펴보세요.'
    : '이번 응답에서 드러난 신호는 제한적입니다. 점검에 담지 못한 사정이나 불편함이 남아 있다면 기록과 상담으로 확인해 볼 수 있습니다.';
  const generalActions = action
    ? [level === 'high' ? '해당 요청이나 표현을 멈추고 상대에게 불이익이 없도록 하세요.' : '업무 목적과 기준을 짧게 설명하세요.', '상대가 질문하거나 거절할 수 있는 여지를 남기세요.', '필요하면 안전한 인사·감사·인권 담당자에게 기준을 확인하세요.']
    : ['날짜, 장소, 말이나 행동을 상황 중심으로 기록하세요.', '신뢰할 수 있는 사람이나 안전한 내부·외부 상담창구를 확인하세요.', '불이익이나 2차 피해가 걱정되면 보호 조치도 문의하세요.'];
  const specificActions = action
    ? actionItemAdvice.filter(([id]) => flaggedItems.includes(id)).map(([, advice]) => advice).slice(0, 2)
    : [];
  const primaryActions = [...specificActions, ...generalActions].slice(0, 3);
  return {
    title: support ? support.title
      : level === 'low' ? '응답에 담긴 상황을 더 살펴보세요' : level === 'high' ? (action ? '행동 중단과 기준 확인을 권장합니다' : '기록과 보호 조치 검토를 권장합니다') : (action ? '표현·방식과 기준을 확인하세요' : '기록과 상담을 권장합니다'),
    summary, primaryActions,
    supportActions: support ? support.actions
      : [action ? '기관의 갑질 예방·인사·복무 기준을 함께 확인하세요.' : '일상에 미친 영향이 크다면 정신건강복지센터나 기관 상담창구도 확인하세요.'],
    supportNotice: support ? support.notice : null,
  };
}
